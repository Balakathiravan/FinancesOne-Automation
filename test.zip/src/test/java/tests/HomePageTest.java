package tests;

import base.BaseTest;
import pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HomePageTest extends BaseTest {

    @Test
    public void homePageLoads() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        Assert.assertTrue(hp.isLoaded(), "Home page did not load correctly.");
    }

    @Test
    public void datasetsNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoDatasets();
         String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("data"),
                "Data tab did not load. Actual title: " + title);
    }

    @Test
    public void financeResultsNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoFinanceResults();
        String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("finance"),
                "Financial Results tab did not load. Actual title: " + title);
    }

    @Test
    public void countriesNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoCountries();
        String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("countries"),
                "Countries/Economies tab did not load. Actual title: " + title);
    }

    @Test
    public void summariesNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoSummaries();
        page.waitForURL("https://financesone.worldbank.org/summaries/ibrd-ida");
        String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("summaries"),
                "Summaries tab did not load. Actual title: " + title);
    }

    @Test
    public void publicationsNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoPublications();
        page.waitForURL("https://financesone.worldbank.org/publications");
        String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("publications"),
                "Publications tab did not load. Actual title: " + title);
    }

    @Test
    public void glossaryNavigation() {
        HomePage hp = new HomePage(page);
        hp.navigate();
        hp.gotoGlossary();
        page.waitForURL("https://financesone.worldbank.org/glossary");
        String title = page.url();
        Assert.assertTrue(title != null && title.toLowerCase().contains("glossary"),
                "Glossary tab did not load. Actual title: " + title);
    }
}
